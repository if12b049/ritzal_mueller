package com.bookserviceapp.filter;

import javax.ws.rs.container.ContainerRequestContext;
import java.io.IOException;

/**
 * Created by Roman on 20.11.2014.
 */
public class Requestfilter{
 
    public void filter(ContainerRequestContext request) throws IOException {


    }
}
