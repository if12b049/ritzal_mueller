package com.bookserviceapp.resources;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Created by Roman on 16.11.2014.
 */
@ApplicationPath("/resources")
public class BookResourceApplication extends Application {
}
